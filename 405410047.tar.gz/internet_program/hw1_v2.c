#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/sendfile.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <errno.h>

#define PORT	8080
#define MAXMSG	512

char webpage[] =
"HTTP/1.1 200 OK\r\n"
"Content-Type: text/html; charset=UTF-8\r\n\r\n"
"<!DOCTYPE html>\r\n"
"<html><head><title>TEST</title>\r\n"
"<style>body { background-color: #FFFF00 }</style></head>\r\n"
"<body><center><h1>Internet Homework1</h1><br>\r\n"
"<img src=\"girl.jpg\"></center></body></html>\r\n";

int read_from_client(int filedes){
	char buf[MAXMSG];
	int nbytes,fdimg;
	nbytes = read(filedes, buf, MAXMSG);
	if(nbytes < 0){
		perror("read");
		exit(EXIT_FAILURE);
	}
	else if(nbytes == 0){ //end
		return -1;
	}
	fprintf(stderr, "Server: got message: '%s'\n",buf);
	if(!strncmp(buf, "GET /favicon.ico",16)){
		printf("favicon\n");
		fdimg = open("favicon.ico",O_RDONLY);
		sendfile(filedes,fdimg, NULL , 6000);
		close(fdimg);
	}
	else if(!strncmp(buf, "GET /girl.jpg",13)){
		printf("girl.jpg");
		fdimg = open("girl.jpg",O_RDONLY);
		sendfile(filedes,fdimg, NULL , 3072000);
		close(fdimg);
	}
	else{
		printf("webpage\n");
		write(filedes, webpage, sizeof(webpage)-1);
	}

	return 0;
}

/*char webpage[] =
"HTTP/1.1 200 OK\r\n"
"Content-Type: text/html; charset=UTF-8\r\n\r\n"
"<!DOCTYPE html>\r\n"
"<html><head><title>TEST</title>\r\n"
"<style>body { background-color: #FFFF00 }</style></head>\r\n"
"<body><center><h1>Internet Homework1</h1><br>\r\n"
"<img src=\"girl.jpg\"></center></body></html>\r\n";*/

int main(int argc , char** argv){
	//extern int make_socket(uint16_t port);
	int sock;
	fd_set active_fd_set, read_fd_set;
	int i,on=1;
	struct sockaddr_in clientname, server_addr;
	socklen_t size;

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if(sock < 0){
		perror("socket");
		exit(EXIT_FAILURE);
	}
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(int));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port = htons(PORT);
	if(bind(sock, (struct sockaddr *)&server_addr, sizeof(server_addr))==-1){
		perror("bind");
		close(sock);
		exit(EXIT_FAILURE);
	}
	if(listen(sock,1)<0){
		perror("listen");
		exit(EXIT_FAILURE);
	}

	FD_ZERO(&active_fd_set);
	FD_SET(sock,&active_fd_set);

	while(1){
		read_fd_set = active_fd_set;
		if(select(FD_SETSIZE, &read_fd_set, NULL, NULL, NULL)<0){
			perror("select");
			exit(EXIT_FAILURE);
		}
		for(i=0;i<FD_SETSIZE;++i){
			if(FD_ISSET(i, &read_fd_set)){
				if(i==sock){
					int new;
					size = sizeof(clientname);
					new = accept(sock,(struct sockaddr*)&clientname, &size);
					if(new < 0){
						perror("accept");
						exit(EXIT_FAILURE);
					}
					fprintf(stderr,"Server: connect from host %s, port %hd.\n",inet_ntoa(clientname.sin_addr),ntohs(clientname.sin_port));
					FD_SET(new, &active_fd_set);
				}
				else{
					if(read_from_client(i)<0){
						close(i);
						FD_CLR(i, &active_fd_set);
					}
				}
			}
		}
	}
	close(sock);







	return 0;
}
